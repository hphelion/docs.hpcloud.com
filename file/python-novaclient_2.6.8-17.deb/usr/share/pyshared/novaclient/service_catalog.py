# Copyright 2011 OpenStack LLC.
# Copyright 2011, Piston Cloud Computing, Inc.
#
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import novaclient.exceptions


class ServiceCatalog(object):
    """Helper methods for dealing with a Keystone Service Catalog."""

    def __init__(self, resource_dict):
        self.catalog = resource_dict

    def get_token(self):
        return self.catalog['access']['token']['id']

    def url_for(self, filters=None,
                    service_type='compute', endpoint_type='publicURL'):
        """Fetch the public URL from the Compute service for
        a particular endpoint attribute. If none given, return
        the first. See tests for sample service catalog."""
        if 'endpoints' in self.catalog:
            # We have a bastardized service catalog. Treat it special. :/
            endpoint = self._filter(self.catalog['endpoints'], filters)
            if endpoint is not None:
                return endpoint[endpoint_type]
            raise novaclient.exceptions.EndpointNotFound()

        # We don't always get a service catalog back ...
        if not 'serviceCatalog' in self.catalog['access']:
            return None

        # Full catalog ...
        catalog = self.catalog['access']['serviceCatalog']

        for service in catalog:
            if service['type'] != service_type:
                continue

            endpoint = self._filter(service['endpoints'], filters)
            if endpoint is not None:
                return endpoint[endpoint_type]

        raise novaclient.exceptions.EndpointNotFound()

    def _filter(self, elements, filters):
        """Return the first element that matches all the filters."""
        if not elements:
            return None
        if not filters:
            return elements[0]
        for element in elements:
            if self._element_matches_filter(element, filters):
                return element

    def _element_matches_filter(self, element, filters):
        """True if the element match all the filters"""
        for key in filters.iterkeys():
            if element[key] != filters[key]:
                return False
        return True

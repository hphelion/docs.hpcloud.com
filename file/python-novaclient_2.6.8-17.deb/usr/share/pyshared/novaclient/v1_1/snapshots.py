"""
Snapshots interface (1.1 extension).
"""

from novaclient import base


class Snapshot(base.Resource):
    """
    A snapshot is a point-in-time backup of a nova volume
    """
    def __repr__(self):
        return "<Snapshot: %s>" % self.id

    def delete(self):
        """
        Delete this snapshot.
        """
        return self.manager.delete(self)


class SnapshotManager(base.ManagerWithFind):
    """
    Manage :class:`Snapshot` resources.
    """
    resource_class = Snapshot

    def create(self, volume_id, force=False):
        """
        Create a snapshot.

        :param volume_id: ID of the volume to create a snapshot of
        :param force: Whether to force the snapshotting of a mounted volume. Defaults to false.
        :rtype: :class:`Snapshot`
        """
        body = {'snapshot': {'volume_id': volume_id,
                            'force': force}}
        return self._create('/os-snapshots', body, 'snapshot')

    def get(self, volume_id):
        """
        Get a snapshot.

        :param snapshot_id: The ID of the snapshot to get.
        :rtype: :class:`Snapshot`
        """
        return self._get("/os-snapshots/%s" % volume_id, "volume")

    def list(self, detailed=True):
        """
        Get a list of all snapshots.

        :rtype: list of :class:`Snapshot`
        """
        if detailed is True:
            return self._list("/os-snapshots/detail", "snapshots")
        else:
            return self._list("/os-snapshots", "snapshots")

    def delete(self, snapshot):
        """
        Delete a snapshot.

        :param snapshot: The :class:`Snapshot` to delete.
        """
        self._delete("/os-snapshots/%s" % base.getid(snapshot))

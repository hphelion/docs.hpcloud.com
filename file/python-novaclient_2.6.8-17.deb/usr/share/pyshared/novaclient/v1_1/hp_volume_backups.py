# Copyright (C) 2012 Hewlett-Packard Development Company, L.P.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""
HP Volume Backups interface (1.1 extension).
"""

from novaclient import base


class HPVolumeBackup(base.Resource):
    """
    A HP volume backup is a block level backup of a volume to swift.
    """
    def __repr__(self):
        return "<HPVolumeBackup: %s>" % self.id

    def delete(self):
        """
        Delete this hp volume backup.
        """
        return self.manager.delete(self)


class HPVolumeBackupManager(base.ManagerWithFind):
    """
    Manage :class:`HPVolumeBackup` resources.
    """
    resource_class = HPVolumeBackup

    def create(self, volume_id, container=None,
                    display_name=None, display_description=None):
        """
        Backup a volume to swift.

        :param volume_id: The ID of the volume to backup.
        :param container: The name of the swift container.
        :param display_name: The name of the HP volume backup.
        :param display_description: The description of the HP volume backup.
        :rtype: :class:`HPVolumeBackup`
        """
        body = {'backup': {'volume_id': volume_id,
                            'container': container,
                            'display_name': display_name,
                            'display_description': display_description}}
        return self._create('/hp-volume-backups', body, 'backup')

    def get(self, backup_id):
        """
        Get a HP volume backup.

        :param backup_id: The ID of the HP backup backup to display.
        :rtype: :class:`HPVolumeBackup`
        """
        return self._get("/hp-volume-backups/%s" % backup_id, "backup")

    def list(self, detailed=True):
        """
        Get a list of all HP volume backups.

        :rtype: list of :class:`HPVolumeBackup`
        """
        if detailed is True:
            return self._list("/hp-volume-backups/detail", "backups")
        else:
            return self._list("/hp-volume-backups", "backups")

    def delete(self, backup):
        """
        Delete a HP volume backup.

        :param backup: The :class:`HPVolumeBackup` to delete.
        """
        self._delete("/hp-volume-backups/%s" % base.getid(backup))

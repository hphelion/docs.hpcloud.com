# Copyright 2011 OpenStack LLC.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

"""
Console Output interface (1.1 extension).
"""

from novaclient import base
from novaclient.v1_1 import base as local_base


class ConsoleOutput(base.Resource):
    def __str__(self):
        return str(self.id)

    def get(self):
        self.manager.get(self)

    def console_output(self):
        self.manager.console_output(self)

    def __repr__(self):
        return "<ConsoleOutput: %s>" % self.name


class ConsoleOutputManager(local_base.BootingManagerWithFind):
    resource_class = ConsoleOutput

    def get(self, id):
        """
        Get a console output

        :param group: The console output to get by ID
        :rtype: :class:`ConsoleOutput`
        """
        return self._get('/os-getConsoleOutput',
                         'Console_output')

    def _action(self, action, server, info=None):
        """
        Perform a server "action" -- Retrieves server log.
        """
        resp, body = self.api.client.post('/servers/%s/action' % server,
                             body={action: info})
        return body

    def console_output(self, server, lines=None):
        """Retrieve server log."""
        if lines == None:
            return self._action('os-getConsoleOutput', server, {})
        else:
            return self._action('os-getConsoleOutput', server,
                               {'length': lines})

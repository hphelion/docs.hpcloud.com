"""
Bock Admin interface (1.1 extension).
"""

from novaclient import base


class BockVdmAdmin(base.Resource):
    """
    Block Storage administration interface.
    """

class BockVdmAdminManager(base.ManagerWithFind):
    """
    Manage :class:`BockVdmAdmin` resources.
    """
    resource_class = BockVdmAdmin

    def list(self):
        """
        Get a list of all vdms.

        :rtype: list of :class:`VirtualDisk`
        """
        return self._list("/bock-admin/vdm", "virtualDiskManager")

    def list_vds(self, vdm_id):
        """
        Get a list of all vds on a vdm.

        :rtype: list of :class:`VirtualDisk`
        """
        return self._list("/bock-admin/vdm/%s/novavolumes" % vdm_id, \
                          "novaVolumes")

    def vd_usage(self, vdm_id, vd_id):
        """
        Lists the usage of a specfic virtual disk.

        :param vdm_id: ID of the virtual disk manager queue
        :param vd: ID of the virtual disk
        :rtype: :class:`novaVolume-usage`
        """
        vd_body = {'virtualDisk-id': vd_id}
        return self._list("/bock-admin/vdm/%s/usage" % vdm_id, \
                          "novaVolumeUsage", body=vd_body)
